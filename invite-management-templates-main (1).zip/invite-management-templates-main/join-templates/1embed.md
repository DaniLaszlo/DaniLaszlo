### Description

A 1 embed join message template with cool emojis

### Emoji Credits

- Original Source: [Icons](https://discord.gg/gpkNkYKr8G)
- Emojis stored in [Invite Management](https://discord.gg/EdT6KNmxSD)

### Template Credits

[Siris#1337](https://discord.com/users/581451736305106985)
[PrinceMorii#6905](https://discord.com/users/197822795256692737)

### Showcase

![showcase](assets/1embed.png 'Showcase')

### Usage

Download [this](assets/1embed.json) JSON and follow the instructions in the README
