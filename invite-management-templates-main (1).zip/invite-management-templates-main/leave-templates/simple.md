### Description

A simple text only leave message template

### Emoji Credits

None

### Template Credits

[Siris#1337](https://discord.com/users/581451736305106985)

### Showcase

![showcase](assets/simple.png 'Showcase')

### Usage

Download [this](assets/simple.json) JSON and follow the instructions in the README